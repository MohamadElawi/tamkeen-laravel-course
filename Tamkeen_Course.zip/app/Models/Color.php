<?php

namespace App\Models;

use App\Enums\StatusEnum;
use Illuminate\Database\Eloquent\Model;

class Color extends Model
{
    protected $table = 'colors';

    protected $fillable = [
        'title' ,
        'status'
    ];

    protected $hidden = [
        'updated_at'
    ];

    protected $casts = [
        'status' => StatusEnum::class
    ];

}

