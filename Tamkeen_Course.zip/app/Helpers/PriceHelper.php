<?php


if(!function_exists('formatPrice')){
    function formatPrice($price){
        return '$' . $price ;
    }
}


if(!function_exists('formatDate')){
    function formatDate($date){
        return $date ;
    }
}
